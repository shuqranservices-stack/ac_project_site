/*
 * Common utility functions for the HVAC project management site.
 *
 * These functions are declared in the global scope so that they
 * can be reused across multiple pages. They depend on the global
 * `data` object provided by data.js and do not require any
 * external libraries. Keeping functionality in a single file
 * helps organise the code base and avoids duplication.
 */

// Colour classes used for summary cards. You can adjust or add
// colours here if you introduce more datasets in the future.
const cardColors = ['primary', 'info', 'warning', 'success', 'secondary'];

// أيقونات لكل Dataset تعرض في بطاقات الملخص
const cardIcons = {
  masterSheet: '📋',
  compressors: '⚙️',
  others: '📦',
  additionalWork: '➕',
  serviceRequest: '📩'
};

// Human‑readable titles for each dataset key. These titles are
// displayed on summary cards and in modal headings. If you add a
// new dataset, update this object accordingly.
const titles = {
  masterSheet: 'البيانات الرئيسية',
  compressors: 'الكمبروسر',
  others: 'أخرى',
  additionalWork: 'الأعمال الإضافية',
  serviceRequest: 'طلبات الخدمة'
};

// Define preferred columns to display for each dataset. This helps
// reduce the number of columns in tables and present a logical order.
// Keys not listed here will be omitted from the table. If a dataset
// does not have an entry in this mapping, all of its keys will be
// shown except those beginning with "Unnamed".
const preferredColumns = {
  masterSheet: [
    'PO numbers',
    'Store_Name',
    'PM_Name',
    'Region',
    'City',
    'Request_Status',
    'Request_Priority',
    'Payment_Status',
    'Date',
    'Amount'
  ],
  compressors: [
    'PO_numbers',
    'Store_Name',
    'PM_Name',
    'Region',
    'City',
    'Type',
    'Model_of_Quotation',
    'Request_Status',
    'Request_Priority',
    'Date'
  ],
  others: [
    'PO_numbers',
    'Store_Name',
    'Brand_Store',
    'City',
    'Type_of_unit',
    'AC_Capacity',
    'Volt',
    'Qty',
    'Request_Status',
    'Request_Priority',
    'Date'
  ],
  additionalWork: [], // Will display no columns because all keys are unnamed
  serviceRequest: [
    'Request No',
    'City',
    'Store Name',
    'INVOICE Number',
    'Request Date',
    'Request_Status',
    'Notes'
  ]
};

// Define human‑readable labels for columns. If a key is not present
// here, the original key name will be used. This map allows us to
// translate English field names into Arabic labels used in the
// tables.
const columnLabels = {
  'PO numbers': 'رقم أمر الشراء',
  'PO_numbers': 'رقم أمر الشراء',
  'Store_Name': 'اسم المتجر',
  'Brand_Store': 'العلامة التجارية',
  'PM_Name': 'مدير المشروع',
  'Region': 'المنطقة',
  'City': 'المدينة',
  'Dept.': 'القسم',
  'Type': 'النوع',
  'Type_of_unit': 'نوع الوحدة',
  'AC_Capacity': 'سعة التكييف',
  'Volt': 'الفولت',
  'Qty': 'الكمية',
  'Request_Status': 'حالة الطلب',
  'Request_Priority': 'أولوية الطلب',
  'Payment_Status': 'حالة الدفع',
  'Date': 'التاريخ',
  'Request Date': 'تاريخ الطلب',
  'INVOICE Number': 'رقم الفاتورة',
  'Notes': 'ملاحظات',
  'Model_of_Quotation': 'طراز العرض',
  'Model_of_Americana': 'طراز أمريكانا',
  'Model_of_Supplier': 'طراز المورد',
  'Amount': 'المبلغ'
  ,
  // اسم لملف نسخة أمر الشراء
  'Acopy_of_PO': 'نسخة أمر الشراء'
};

// Pre‑rendered HTML for the Alshagran logo used as a hyperlink label. The
// image file must exist in `assets/images` relative to each page. When
// a cell contains a URL, this HTML will be used inside the anchor
// instead of a text label.
const logoImgHtml = '<img src="assets/images/alshgran-logo.png" alt="Alshagran logo" class="logo-icon">';

/**
 * Render a grouped table for the master dataset (البيانات الرئيسية). When a
 * purchase order number appears multiple times (indicating multiple items
 * for the same PO), this function groups those rows together. Each unique
 * PO number renders a single high‑level row showing summary information
 * (e.g. PO number, store name, region, status, priority, payment status,
 * date and total amount). Directly beneath it, a nested table lists all
 * items associated with that PO along with their specific fields (e.g.
 * type of unit, capacity, quantity, brand). This avoids repetition of
 * identical summary data and provides a concise view of the items.
 *
 * @param {string} containerId - The ID of the element where the table should be inserted.
 * @param {string} datasetKey - The dataset key (should be 'masterSheet').
 * @param {Array<Object>|null} recordsOverride - Optional array of records (after filtering).
 */
function renderMasterTable(containerId, datasetKey, recordsOverride = null) {
  const container = document.getElementById(containerId);
  const records = Array.isArray(recordsOverride)
    ? recordsOverride
    : Array.isArray(data[datasetKey])
    ? data[datasetKey]
    : [];
  // If there are no records, display message and return
  if (!records || records.length === 0) {
    container.innerHTML = '<p>لا توجد سجلات لعرضها.</p>';
    return;
  }
  // Group records by PO number (first preferred column)
  const groups = {};
  const keyField = preferredColumns[datasetKey] && preferredColumns[datasetKey].length > 0
    ? preferredColumns[datasetKey][0]
    : 'PO numbers';
  records.forEach(rec => {
    const po = rec[keyField];
    if (!groups[po]) groups[po] = [];
    groups[po].push(rec);
  });
  // Define which columns to display in the summary row (main row). These
  // correspond to the primary fields you want visible without expanding
  // item details. Adjust this list to show more or fewer fields.
  const summaryCols = [
    keyField,
    'Store_Name',
    'PM_Name',
    'Region',
    'City',
    'Request_Status',
    'Request_Priority',
    'Payment_Status',
    'Date',
    'Amount'
  ];
  // Determine item columns by taking all keys from the first record and
  // removing the summary columns and any unnamed columns. This ensures
  // nested table displays detailed fields such as equipment specs and
  // component quantities.
  const allKeys = Object.keys(records[0]);
  const itemCols = allKeys.filter(
    k => !summaryCols.includes(k) && !/^Unnamed/.test(k)
  );
  let html = '<div class="table-responsive">';
  html += '<table class="data-table master-group-table">';
  // Header row for summary table
  html += '<thead><tr>';
  summaryCols.forEach(col => {
    const label = columnLabels[col] || col;
    html += `<th>${label}</th>`;
  });
  html += '</tr></thead><tbody>';
  // Generate rows per PO group
  Object.keys(groups).forEach(po => {
    const groupRecords = groups[po];
    const first = groupRecords[0];
    html += '<tr class="master-row">';
    summaryCols.forEach(col => {
      let value = first[col];
      if (value === undefined || value === null) value = '';
      let cellHtml = value;
      // Convert URLs to clickable logo
      if (typeof value === 'string' && /^(https?:\/\/)/.test(value)) {
        cellHtml = `<a href="${value}" target="_blank">${logoImgHtml}</a>`;
      }
      // Payment status badge
      if (col === 'Payment_Status' && typeof value === 'string' && value) {
        const statusClass = 'status-' + value.replace(/\s+/g, '');
        cellHtml = `<span class="status-badge ${statusClass}">${value}</span>`;
      }
      html += `<td>${cellHtml}</td>`;
    });
    html += '</tr>';
    // Nested row for item details
    html += `<tr class="master-item-row"><td colspan="${summaryCols.length}">`;
    html += '<table class="nested-item-table">';
    // Header for nested table
    html += '<thead><tr>';
    itemCols.forEach(col => {
      const label = columnLabels[col] || col;
      html += `<th>${label}</th>`;
    });
    html += '</tr></thead><tbody>';
    groupRecords.forEach(item => {
      html += '<tr>';
      itemCols.forEach(col => {
        let val = item[col];
        if (val === undefined || val === null) val = '';
        let nestedCell = val;
        if (typeof val === 'string' && /^(https?:\/\/)/.test(val)) {
          nestedCell = `<a href="${val}" target="_blank">${logoImgHtml}</a>`;
        }
        if (col === 'Payment_Status' && typeof val === 'string' && val) {
          const statusClass = 'status-' + val.replace(/\s+/g, '');
          nestedCell = `<span class="status-badge ${statusClass}">${val}</span>`;
        }
        html += `<td>${nestedCell}</td>`;
      });
      html += '</tr>';
    });
    html += '</tbody></table></td></tr>';
  });
  html += '</tbody></table></div>';
  container.innerHTML = html;
}

/**
 * Render a responsive HTML table for a given dataset. The table is
 * completely regenerated on each call to reflect the current state
 * of the data. If there are no records in the dataset, a message
 * indicating the absence of data is displayed instead.
 *
 * @param {string} containerId - The ID of the element where the
 *                               table should be inserted.
 * @param {string} datasetKey - The key in the global `data` object
 *                              corresponding to the dataset.
 */
function renderTable(containerId, datasetKey, recordsOverride = null) {
  const container = document.getElementById(containerId);
  // Allow passing a custom array of records (e.g. filtered). If null,
  // fall back to the global data for the dataset key.
  const records = Array.isArray(recordsOverride)
    ? recordsOverride
    : Array.isArray(data[datasetKey])
    ? data[datasetKey]
    : [];
  // Choose which headers to display based on preferredColumns. If no
  // preferred columns are defined or the array is empty, fall back to
  // using all keys from the first record except those starting with
  // "Unnamed".
  let headers = [];
  if (preferredColumns[datasetKey] && preferredColumns[datasetKey].length > 0) {
    headers = preferredColumns[datasetKey];
  } else if (records.length > 0) {
    headers = Object.keys(records[0]).filter(k => !/^Unnamed/.test(k));
  }
  let html = '';
  if (headers.length > 0) {
    // Wrap the table in a responsive container so wide tables scroll horizontally
    html += '<div class="table-responsive">';
    html += '<table class="data-table">';
    // Table head
    html += '<thead><tr>';
    headers.forEach(key => {
      // Use custom label if defined
      const label = columnLabels[key] || key;
      html += `<th>${label}</th>`;
    });
    html += '</tr></thead>';
    // Table body
    html += '<tbody>';
    records.forEach(record => {
      html += '<tr>';
      headers.forEach(key => {
        const cellValue = record[key] !== undefined && record[key] !== null ? record[key] : '';
        let cellHtml = cellValue;
        // If the cell value is a URL, replace it with the clickable logo image
        if (typeof cellValue === 'string' && /^(https?:\/\/)/.test(cellValue)) {
          cellHtml = `<a href="${cellValue}" target="_blank">${logoImgHtml}</a>`;
        }
        // Apply coloured status badge for payment status values
        if (key === 'Payment_Status' && typeof cellValue === 'string' && cellValue) {
          const statusClass = 'status-' + cellValue.replace(/\s+/g, '');
          cellHtml = `<span class="status-badge ${statusClass}">${cellValue}</span>`;
        }
        html += `<td>${cellHtml}</td>`;
      });
      html += '</tr>';
    });
    html += '</tbody></table>';
    html += '</div>';
  } else {
    html = '<p>لا توجد سجلات لعرضها.</p>';
  }
  container.innerHTML = html;

  // After rendering the table, attach click listeners to each row
  if (records.length > 0 && headers.length > 0) {
    const tableElem = container.querySelector('table');
    if (tableElem) {
      const rowElems = tableElem.querySelectorAll('tbody tr');
      rowElems.forEach((rowElem, index) => {
        rowElem.addEventListener('click', () => {
          // Show detailed view for the clicked record
          showRecordDetails(records[index]);
        });
        // Change cursor to pointer to indicate clickability
        rowElem.style.cursor = 'pointer';
      });
    }
  }
}

/**
 * Render summary cards showing the count of records in each dataset.
 * The cards are appended into the given container element. Each
 * dataset defined in the global `titles` object will produce one
 * card. The order of cards is determined by the order of keys in
 * `titles`.
 *
 * @param {string} containerId - The ID of the element where the
 *                               summary cards should be inserted.
 */
function renderSummary(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = '';
  let index = 0;
  Object.keys(titles).forEach(key => {
    let count = 0;
    // Count unique records based on the first preferred column (e.g. PO number)
    if (Array.isArray(data[key])) {
      const dataset = data[key];
      // Determine unique key field
      const prefCols = preferredColumns[key];
      let uniqueField = null;
      if (Array.isArray(prefCols) && prefCols.length > 0) {
        uniqueField = prefCols[0];
      }
      if (uniqueField) {
        const seen = new Set();
        dataset.forEach(rec => {
          const val = rec[uniqueField];
          if (val !== undefined && val !== null) {
            seen.add(val);
          }
        });
        count = seen.size;
      } else {
        // fall back to total records
        count = dataset.length;
      }
    }
    const colour = cardColors[index % cardColors.length];
    const card = document.createElement('div');
    // اختر أيقونة للتصنيف، إذا لم توجد استخدم رمز افتراضي
    const icon = cardIcons[key] || '📄';
    card.innerHTML = `\
      <div class="card-summary bg-${colour}">\
        <span class="icon">${icon}</span>\
        <h3>${titles[key]}</h3>\
        <p>${count}</p>\
      </div>`;
    container.appendChild(card);
    index++;
  });
}

/**
 * Get a sorted array of unique values for a given column in a dataset.
 * Empty, null or undefined values are ignored. Useful for building
 * dropdown filters.
 *
 * @param {string} datasetKey - Key of the dataset in the global data object.
 * @param {string} column - Name of the column to extract values from.
 * @returns {Array<string>} Sorted array of distinct values.
 */
function getUniqueValues(datasetKey, column) {
  const records = Array.isArray(data[datasetKey]) ? data[datasetKey] : [];
  const values = new Set();
  records.forEach(rec => {
    const val = rec[column];
    if (val !== undefined && val !== null && val !== '') {
      values.add(val);
    }
  });
  return Array.from(values).sort();
}

/**
 * Filter records in a dataset according to a set of filter conditions.
 * Each filter is defined by a column name and a selected value. If a
 * filter's value is 'all' (case‑insensitive) or an empty string, that
 * filter is ignored. Returns a new array of records that satisfy all
 * filters.
 *
 * @param {string} datasetKey - Key of the dataset in the global data object.
 * @param {Object} filters - Mapping of column names to selected values.
 * @returns {Array<Object>} The filtered records.
 */
function applyFilters(datasetKey, filters) {
  const records = Array.isArray(data[datasetKey]) ? data[datasetKey] : [];
  return records.filter(record => {
    return Object.keys(filters).every(col => {
      const selected = filters[col];
      if (!selected || selected.toLowerCase() === 'all') return true;
      return String(record[col]) === selected;
    });
  });
}

/**
 * Set up filter dropdowns for a dataset. Creates select elements for
 * each specified field, populates them with unique values from the
 * dataset, and attaches change handlers to update the table. This
 * function should be called from the page script after the DOM has
 * loaded. It will insert filter controls into the specified container.
 *
 * @param {string} datasetKey - Key of the dataset to filter.
 * @param {Array<string>} filterFields - Array of column names to create filters for.
 * @param {string} filterContainerId - ID of the container where filter controls should be inserted.
 * @param {string} tableContainerId - ID of the table container to re‑render when filters change.
 */
function setupFilters(datasetKey, filterFields, filterContainerId, tableContainerId, renderFunc = renderTable) {
  const container = document.getElementById(filterContainerId);
  if (!container) return;
  // Clear any existing filters
  container.innerHTML = '';
  const filters = {};
  filterFields.forEach(field => {
    const labelText = columnLabels[field] || field;
    const wrapper = document.createElement('div');
    wrapper.classList.add('filter-group');
    const label = document.createElement('label');
    label.textContent = labelText;
    label.setAttribute('for', `filter-${field}`);
    const select = document.createElement('select');
    select.id = `filter-${field}`;
    select.classList.add('filter-select');
    // Default option
    const defaultOpt = document.createElement('option');
    defaultOpt.value = '';
    defaultOpt.textContent = 'الكل';
    select.appendChild(defaultOpt);
    // Populate with unique values
    const values = getUniqueValues(datasetKey, field);
    values.forEach(val => {
      const opt = document.createElement('option');
      opt.value = String(val);
      opt.textContent = String(val);
      select.appendChild(opt);
    });
    // Update filters and table when selection changes
    select.addEventListener('change', () => {
      filters[field] = select.value;
      const filtered = applyFilters(datasetKey, filters);
      // Use provided render function to re-render the table. This allows
      // custom table rendering logic (e.g. grouping rows) for specific datasets.
      renderFunc(tableContainerId, datasetKey, filtered);
    });
    wrapper.appendChild(label);
    wrapper.appendChild(select);
    container.appendChild(wrapper);
  });
}

/**
 * Display a modal with details of a record. Uses the existing addModal
 * structure but hides the save button and shows all fields in a
 * read‑only format. The record object is iterated and each key/value
 * pair is displayed on its own line with a label.
 *
 * @param {Object} record - The data record to display.
 */
function showRecordDetails(record) {
  const modal = document.getElementById('addModal');
  const title = document.getElementById('addModalLabel');
  const form = document.getElementById('add-form');
  const saveButton = document.getElementById('save-record-btn');
  // Reset form contents
  form.innerHTML = '';
  // Build a table to display details in two columns (label and value)
  const table = document.createElement('table');
  table.classList.add('details-table');
  const tbody = document.createElement('tbody');
  Object.keys(record).forEach(key => {
    const value = record[key] !== undefined && record[key] !== null ? record[key] : '';
    const label = columnLabels[key] || key;
    // Determine display value: convert URLs to clickable logo and add badge to payment status
    let displayValue = value;
    if (typeof value === 'string' && /^(https?:\/\/)/.test(value)) {
      displayValue = `<a href="${value}" target="_blank">${logoImgHtml}</a>`;
    }
    if (key === 'Payment_Status' && typeof value === 'string' && value) {
      const statusClass = 'status-' + value.replace(/\s+/g, '');
      displayValue = `<span class="status-badge ${statusClass}">${value}</span>`;
    }
    const tr = document.createElement('tr');
    const th = document.createElement('th');
    th.classList.add('detail-label');
    th.textContent = label;
    const td = document.createElement('td');
    td.classList.add('detail-value');
    td.innerHTML = displayValue;
    tr.appendChild(th);
    tr.appendChild(td);
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  // Append details table to form
  form.appendChild(table);
  // Hide save button for details view
  if (saveButton) saveButton.style.display = 'none';
  title.textContent = 'تفاصيل السجل';
  modal.classList.add('show');
  // Close modal on clicking the close button or cancel
  const closeBtn = modal.querySelector('.btn-close');
  const cancelBtn = modal.querySelector('.btn.btn-secondary');
  if (closeBtn) {
    closeBtn.onclick = () => {
      modal.classList.remove('show');
      if (saveButton) saveButton.style.display = '';
    };
  }
  if (cancelBtn) {
    cancelBtn.onclick = () => {
      modal.classList.remove('show');
      if (saveButton) saveButton.style.display = '';
    };
  }
}

// Variables to keep track of the dataset and table currently being edited
let currentDatasetKey = null;
let currentTableContainerId = null;

/**
 * Open a modal dialog to add a new record to the specified dataset. It
 * dynamically generates input fields based on the keys of the first
 * record in the dataset. When the modal is shown, the user can
 * populate the fields and save the record. This function stores
 * references in module‑level variables so that saveRecord() knows
 * which dataset and table to update.
 *
 * @param {string} datasetKey - Key of the dataset in the global `data` object.
 * @param {string} tableContainerId - ID of the container where the table
 *                                    is rendered (used for re‑rendering).
 */
function openAddModal(datasetKey, tableContainerId) {
  currentDatasetKey = datasetKey;
  currentTableContainerId = tableContainerId;
  const modal = document.getElementById('addModal');
  const modalTitle = document.getElementById('addModalLabel');
  const form = document.getElementById('add-form');
  form.innerHTML = '';
  const records = Array.isArray(data[datasetKey]) ? data[datasetKey] : [];
  if (records.length === 0) {
    form.innerHTML = '<p>لا يمكن إضافة سجلات جديدة لأنه لا توجد بنية بيانات معروفة.</p>';
  } else {
    const sample = records[0];
    Object.keys(sample).forEach(key => {
      const group = document.createElement('div');
      group.classList.add('form-group');
      const label = document.createElement('label');
      label.setAttribute('for', `input-${key}`);
      label.textContent = key;
      const input = document.createElement('input');
      input.type = 'text';
      input.id = `input-${key}`;
      input.name = key;
      input.classList.add('form-control');
      group.appendChild(label);
      group.appendChild(input);
      form.appendChild(group);
    });
  }
  modalTitle.textContent = 'إضافة سجل جديد - ' + titles[datasetKey];
  modal.classList.add('show');
}

/**
 * Close the add record modal and reset tracking variables. This
 * function simply hides the modal by removing the `show` class and
 * clears the current dataset and table references.
 */
function closeModal() {
  const modal = document.getElementById('addModal');
  modal.classList.remove('show');
  currentDatasetKey = null;
  currentTableContainerId = null;
}

/**
 * Save the record currently being edited in the modal. It reads all
 * form fields from the modal form, constructs a new object, appends
 * it to the appropriate dataset and then re‑renders both the table and
 * the summary cards (if a summary container exists on the page).
 */
function saveRecord() {
  if (!currentDatasetKey || !currentTableContainerId) return;
  const form = document.getElementById('add-form');
  const formData = new FormData(form);
  const newRecord = {};
  for (const [key, value] of formData.entries()) {
    newRecord[key] = value;
  }
  // Append the new record to the dataset
  data[currentDatasetKey].push(newRecord);
  // Re‑render the table
  renderTable(currentTableContainerId, currentDatasetKey);
  // If a summary section exists on the page, update it
  const summary = document.getElementById('summary-cards');
  if (summary) {
    renderSummary('summary-cards');
  }
  closeModal();
}

// Attach click handlers to modal close buttons and save button once
// the DOM content is loaded. This ensures that the elements exist
// before we attempt to bind events to them.
document.addEventListener('DOMContentLoaded', function () {
  const modal = document.getElementById('addModal');
  if (!modal) return;
  const closeButtons = modal.querySelectorAll('.btn-close, .btn-secondary');
  closeButtons.forEach(btn => {
    btn.addEventListener('click', function () {
      closeModal();
    });
  });
  const saveButton = document.getElementById('save-record-btn');
  if (saveButton) {
    saveButton.addEventListener('click', function () {
      saveRecord();
    });
  }
});