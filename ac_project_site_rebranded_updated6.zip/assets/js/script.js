/*
 * Custom JavaScript for the HVAC project management app.
 *
 * This script avoids any external dependencies (such as jQuery or DataTables)
 * and instead uses vanilla JavaScript to handle navigation, table rendering,
 * dashboard summaries and a simple modal form for adding records. Keeping
 * everything self‑contained ensures the site works even when external
 * CDNs are unreachable.
 */

document.addEventListener('DOMContentLoaded', function () {
  // Cache references to page elements
  const navLinks = document.querySelectorAll('.nav-link');
  const sections = document.querySelectorAll('.page-section');
  const dashboardContainer = document.getElementById('dashboard-cards');
  // Modal elements
  const modal = document.getElementById('addModal');
  const modalTitle = document.getElementById('addModalLabel');
  const form = document.getElementById('add-form');
  const saveButton = document.getElementById('save-record-btn');
  const closeButtons = modal.querySelectorAll('.btn-close, .btn-secondary');

  // Keep track of the current dataset and table for adding records
  let currentDataset = null;
  let currentTableId = null;

  // Define color classes for summary cards
  const cardColors = ['primary', 'info', 'warning', 'success', 'secondary'];
  // Human readable titles for each dataset key
  const titles = {
    masterSheet: 'البيانات الرئيسية',
    compressors: 'الكمبروسر',
    others: 'أخرى',
    additionalWork: 'الأعمال الإضافية',
    serviceRequest: 'طلبات الخدمة'
  };

  /**
   * Show the requested section and mark the clicked nav link as active.
   */
  navLinks.forEach(function (link) {
    link.addEventListener('click', function (e) {
      e.preventDefault();
      const target = this.dataset.target;
      // update active classes
      navLinks.forEach(l => l.classList.remove('active'));
      this.classList.add('active');
      // hide all sections then show the target section
      sections.forEach(sec => sec.classList.add('d-none'));
      const section = document.getElementById(target);
      if (section) {
        section.classList.remove('d-none');
      }
    });
  });

  /**
   * Render the summary cards on the dashboard. Each card displays
   * the count of records in its respective dataset.
   */
  function updateDashboard() {
    dashboardContainer.innerHTML = '';
    let index = 0;
    Object.keys(titles).forEach(function (key) {
      const count = Array.isArray(data[key]) ? data[key].length : 0;
      const color = cardColors[index % cardColors.length];
      const card = document.createElement('div');
      card.classList.add('col', 'col-sm-6', 'col-lg-3');
      card.innerHTML = `\
        <div class="card-summary bg-${color}">\
          <div class="h5">${titles[key]}</div>\
          <div class="count">${count}</div>\
        </div>`;
      dashboardContainer.appendChild(card);
      index++;
    });
  }

  /**
   * Render a simple HTML table for a given dataset. The table is
   * re‑generated on each call to reflect the latest data. A reference
   * to the rendered table is not stored because we recreate it
   * wholesale whenever data changes.
   *
   * @param {string} containerId - The ID of the element where the table
   *                               should be inserted.
   * @param {string} datasetKey - The key in the global `data` object.
   */
  function renderTable(containerId, datasetKey) {
    const container = document.getElementById(containerId);
    const records = Array.isArray(data[datasetKey]) ? data[datasetKey] : [];
    // Determine table headers from the keys of the first record
    const headers = records.length > 0 ? Object.keys(records[0]) : [];
    let html = '';
    if (headers.length > 0) {
      // Wrap the table in a responsive container so wide tables scroll horizontally
      html += '<div class="table-responsive">';
      html += '<table class="data-table">';
      // Table head
      html += '<thead><tr>';
      headers.forEach(key => {
        html += `<th>${key}</th>`;
      });
      html += '</tr></thead>';
      // Table body
      html += '<tbody>';
      records.forEach(record => {
        html += '<tr>';
        headers.forEach(key => {
          html += `<td>${record[key] !== undefined ? record[key] : ''}</td>`;
        });
        html += '</tr>';
      });
      html += '</tbody></table>';
      html += '</div>';
    } else {
      // No records: display a message
      html = '<p>لا توجد سجلات لعرضها.</p>';
    }
    container.innerHTML = html;
  }

  /**
   * Opens the modal for adding a new record to the specified dataset.
   * It dynamically generates input fields based on the keys of the first
   * existing record (if any). If there are no records, no fields are
   * generated and the user will not be able to add data.
   *
   * @param {string} datasetKey - Key of the dataset in the global `data` object.
   * @param {string} tableContainerId - ID of the container where the table
   *                                    is rendered (used for re‑rendering).
   */
  function openAddModal(datasetKey, tableContainerId) {
    currentDataset = datasetKey;
    currentTableId = tableContainerId;
    const records = Array.isArray(data[datasetKey]) ? data[datasetKey] : [];
    form.innerHTML = '';
    if (records.length === 0) {
      form.innerHTML = '<p>لا يمكن إضافة سجلات جديدة لأنه لا توجد بنية بيانات معروفة.</p>';
    } else {
      const sample = records[0];
      Object.keys(sample).forEach(function (key) {
        const group = document.createElement('div');
        group.classList.add('form-group');
        const label = document.createElement('label');
        label.setAttribute('for', `input-${key}`);
        label.textContent = key;
        const input = document.createElement('input');
        input.type = 'text';
        input.id = `input-${key}`;
        input.name = key;
        input.classList.add('form-control');
        group.appendChild(label);
        group.appendChild(input);
        form.appendChild(group);
      });
    }
    modalTitle.textContent = 'إضافة سجل جديد - ' + titles[datasetKey];
    modal.classList.add('show');
  }

  /**
   * Close the modal and reset state.
   */
  function closeModal() {
    modal.classList.remove('show');
    currentDataset = null;
    currentTableId = null;
  }

  // Bind click events to close buttons within the modal
  closeButtons.forEach(btn => {
    btn.addEventListener('click', function () {
      closeModal();
    });
  });

  // Bind Add buttons
  document.getElementById('add-master-btn').addEventListener('click', function () {
    openAddModal('masterSheet', 'master-section-table');
  });
  document.getElementById('add-compressors-btn').addEventListener('click', function () {
    openAddModal('compressors', 'compressors-section-table');
  });
  document.getElementById('add-others-btn').addEventListener('click', function () {
    openAddModal('others', 'others-section-table');
  });
  document.getElementById('add-additional-btn').addEventListener('click', function () {
    openAddModal('additionalWork', 'additional-section-table');
  });
  document.getElementById('add-service-btn').addEventListener('click', function () {
    openAddModal('serviceRequest', 'service-section-table');
  });

  // Handle saving a new record
  saveButton.addEventListener('click', function () {
    if (!currentDataset || !currentTableId) return;
    const formData = new FormData(form);
    const newRecord = {};
    for (const [key, value] of formData.entries()) {
      newRecord[key] = value;
    }
    // Append the new record to the dataset
    data[currentDataset].push(newRecord);
    // Re‑render the table and update dashboard
    renderTable(currentTableId, currentDataset);
    updateDashboard();
    // Close modal
    closeModal();
  });

  // Initialize the dashboard and tables on first load
  updateDashboard();
  renderTable('master-section-table', 'masterSheet');
  renderTable('compressors-section-table', 'compressors');
  renderTable('others-section-table', 'others');
  renderTable('additional-section-table', 'additionalWork');
  renderTable('service-section-table', 'serviceRequest');
});